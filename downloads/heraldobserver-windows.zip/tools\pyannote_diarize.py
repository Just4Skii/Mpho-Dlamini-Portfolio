#!/usr/bin/env python3
"""
pyannote Community-1 bridge for Herald Observer
Windows deployment: requires python 3.10+, torch, pyannote.audio, huggingface_hub

Install:
  pip install "pyannote.audio[community]" huggingface_hub torch torchaudio --extra-index-url https://download.pytorch.org/whl/cu121  # or cpu
  huggingface-cli login  # paste HF token with access to pyannote/speaker-diarization-community-1
  # or set env HUGGING_FACE_HUB_TOKEN

Usage:
  python tools/pyannote_diarize.py --input input.wav --output out.rttm --num-speakers 3
  python tools/pyannote_diarize.py --input chunk.pcm --sample-rate 16000 --num-speakers 3 --output out.rttm

Input: WAV/PCM 16k mono or any ffmpeg-decodable. Output: RTTM.
For raw PCM, we wrap as WAV on the fly.

Exits 0 on success, 2 if model/auth missing, 3 if pyannote not installed.
"""
import argparse, sys, os, tempfile, wave, pathlib
# Disable torchcodec on Windows Python 3.14/3.11 where libtorchcodec DLLs mismatch — use torchaudio backend
os.environ["TORCHCODEC_DISABLE"] = "1"
os.environ["PYANNOTE_AUDIO_TORCHCODEC"] = "0"

def pcm_to_wav(pcm_path, sr, wav_path):
    with open(pcm_path, 'rb') as f: data = f.read()
    # assume PCM16 mono
    with wave.open(wav_path, 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr); w.writeframes(data)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--input', required=True, help='input wav/pcm')
    ap.add_argument('--output', required=True, help='output rttm')
    ap.add_argument('--num-speakers', type=int, default=3)
    ap.add_argument('--sample-rate', type=int, default=16000, help='for .pcm input')
    ap.add_argument('--model', default='pyannote/speaker-diarization-community-1')
    ap.add_argument('--hf-token', default=None, help='or env HUGGING_FACE_HUB_TOKEN')
    args = ap.parse_args()

    token = args.hf_token or os.environ.get('HUGGING_FACE_HUB_TOKEN') or os.environ.get('HF_TOKEN')
    if not token:
        # try reading from %LOCALAPPDATA%\HeraldObserver\hf_token.txt
        try:
            p = pathlib.Path(os.environ.get('LOCALAPPDATA','')) / 'HeraldObserver' / 'hf_token.txt'
            if p.exists(): token = p.read_text().strip()
        except: pass

    try:
        import torch
        from pyannote.audio import Pipeline
    except ImportError as e:
        print(f"MISSING_PYANNOTE: {e}", file=sys.stderr)
        print("Install: pip install \"pyannote.audio[community]\" huggingface_hub torch", file=sys.stderr)
        sys.exit(3)

    wav_path = args.input
    tmp_wav = None
    if wav_path.lower().endswith('.pcm'):
        tmp_wav = tempfile.mktemp(suffix='.wav')
        pcm_to_wav(wav_path, args.sample_rate, tmp_wav)
        wav_path = tmp_wav

    if not os.path.exists(wav_path):
        print(f"Input not found: {wav_path}", file=sys.stderr); sys.exit(2)

    # Device
    device = "cuda" if hasattr(torch, 'cuda') and torch.cuda.is_available() else "cpu"
    print(f"pyannote device={device} model={args.model} speakers={args.num_speakers}", file=sys.stderr)

    # HF auth: newer pyannote uses token=, not use_auth_token; also works via env/hf cache
    pipeline = None
    last_err = None
    for kwargs in [ {"token": token}, {"use_auth_token": token}, {} ]:
        if kwargs and not token: continue
        try:
            # Filter empty token
            if "token" in kwargs and not kwargs["token"]: continue
            if "use_auth_token" in kwargs and not kwargs["use_auth_token"]: continue
            pipeline = Pipeline.from_pretrained(args.model, **kwargs)
            break
        except TypeError as e:
            last_err = e
            continue
        except Exception as e:
            last_err = e
            # If auth error, try next variant
            if "use_auth_token" in str(e) or "token" in str(e): continue
            break
    if pipeline is None:
        # final try without token (maybe cached login)
        try:
            pipeline = Pipeline.from_pretrained(args.model)
        except Exception as e:
            print(f"MODEL_AUTH_FAILED: {last_err or e}", file=sys.stderr)
            print("Get access at https://huggingface.co/pyannote/speaker-diarization-community-1 and run huggingface-cli login", file=sys.stderr)
            sys.exit(2)

    if device == "cuda":
        try: pipeline.to(torch.device("cuda"))
        except: pass

    # Try file path first (needs torchcodec), fallback to waveform via torchaudio/soundfile
    diarization = None
    def try_waveform():
        print("torchcodec missing, falling back to torchaudio/soundfile", file=sys.stderr)
        waveform = None
        sr = 16000
        try:
            import torchaudio
            waveform, sr = torchaudio.load(wav_path)
        except Exception:
            try:
                import soundfile as sf
                data, sr = sf.read(wav_path, dtype='float32', always_2d=True)
                import torch
                waveform = torch.from_numpy(data.T)
            except Exception as e2:
                raise RuntimeError(f"Failed to load audio without torchcodec: {e2}") from e
        try:
            return pipeline({"waveform": waveform, "sample_rate": sr}, num_speakers=args.num_speakers)
        except TypeError:
            return pipeline({"waveform": waveform, "sample_rate": sr})
    try:
        diarization = pipeline(wav_path, num_speakers=args.num_speakers)
    except TypeError:
        try:
            diarization = pipeline(wav_path)
        except RuntimeError as e:
            if "torchcodec" in str(e):
                diarization = try_waveform()
            else:
                raise
    except RuntimeError as e:
        if "torchcodec" not in str(e):
            raise
        diarization = try_waveform()

    # Write RTTM — handle pyannote 4.x DiarizeOutput vs Annotation
    print(f"DEBUG diarization type={type(diarization).__name__} dir={ [x for x in dir(diarization) if not x.startswith('_')][:15]}", file=sys.stderr)
    ann = None
    # Try common attributes
    for attr in ["diarization", "exclusive", "annotation", "hard_clusters", "soft_clusters"]:
        if hasattr(diarization, attr):
            try:
                cand = getattr(diarization, attr)
                if cand is not None and hasattr(cand, "itertracks"):
                    ann = cand
                    print(f"DEBUG using attribute {attr}", file=sys.stderr)
                    break
                if cand is not None and hasattr(cand, "write_rttm"):
                    ann = cand
                    print(f"DEBUG using attribute {attr} (write_rttm)", file=sys.stderr)
                    break
            except: pass
    if ann is None:
        # Check if diarization is dict-like
        if isinstance(diarization, dict) and "diarization" in diarization:
            ann = diarization["diarization"]
        elif hasattr(diarization, "__dict__"):
            print(f"DEBUG __dict__ keys={list(diarization.__dict__.keys())}", file=sys.stderr)
            for k,v in diarization.__dict__.items():
                if hasattr(v, "itertracks"):
                    ann = v
                    print(f"DEBUG using __dict__[{k}]", file=sys.stderr)
                    break
        if ann is None and hasattr(diarization, "write_rttm"):
            ann = diarization
        if ann is None:
            ann = diarization
            print("DEBUG fallback to raw output", file=sys.stderr)

    with open(args.output, 'w') as f:
        try:
            if hasattr(ann, "write_rttm"):
                ann.write_rttm(f)
            else:
                raise AttributeError("no write_rttm")
        except Exception as e:
            print(f"DEBUG write_rttm failed {e}, manual write", file=sys.stderr)
            try:
                for turn, _, speaker in ann.itertracks(yield_label=True):
                    f.write(f"SPEAKER {os.path.basename(args.input)} 1 {turn.start:.3f} {(turn.end - turn.start):.3f} <NA> <NA> {speaker} <NA> <NA>\n")
            except Exception as e2:
                print(f"DEBUG manual itertracks also failed {e2}", file=sys.stderr)
                # Try to iterate as list of segments if ann is list
                try:
                    for seg in ann:
                        f.write(f"SPEAKER {os.path.basename(args.input)} 1 {seg.start:.3f} {(seg.end - seg.start):.3f} <NA> <NA> SPEAKER_00 <NA> <NA>\n")
                except: pass

    # Also print segments for C# to parse if needed
    try:
        for turn, _, speaker in ann.itertracks(yield_label=True):
            print(f"{turn.start:.3f} {turn.end:.3f} {speaker}")
    except Exception as e:
        print(f"WARN itertracks failed: {e} ann type {type(ann).__name__}", file=sys.stderr)
        try:
            print(f"DEBUG ann dir { [x for x in dir(ann) if not x.startswith('_')][:20]}", file=sys.stderr)
        except: pass

    if tmp_wav and os.path.exists(tmp_wav):
        try: os.remove(tmp_wav)
        except: pass

if __name__ == '__main__':
    main()
